# FashionStar串行总线舵机SDK(Python2)

使用说明: 
* [串行总线舵机SDK使用手册(Python2)](doc/串行总线舵机SDK使用手册(Python2)/串行总线舵机SDK使用手册(Python2).pdf)